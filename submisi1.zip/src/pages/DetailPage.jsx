import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import {
  asyncReceiveThreadDetail,
  asyncAddComment,
  asyncToggleUpvoteComment,
} from '../states/threads/threadDetailSlice';

function DetailPage() {
  const { id } = useParams();
  const dispatch = useDispatch();
  const { threadDetail, authUser } = useSelector((state) => state); // Mengambil data user yang sedang login

  const [commentText, setCommentText] = useState('');

  useEffect(() => {
    dispatch(asyncReceiveThreadDetail(id));
  }, [id, dispatch]);

  const onCommentSubmit = (e) => {
    e.preventDefault();
    dispatch(asyncAddComment({ threadId: id, content: commentText }));
    setCommentText('');
  };

  if (threadDetail === null) {
    return <p style={{ padding: '20px' }}>Memuat diskusi...</p>;
  }

  return (
    <div>
      <section className="ml-6"></section>
      <section style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
        <Link to="/" style={{ textDecoration: 'none', color: 'blue' }}>
          &larr; Kembali
        </Link>

        {/* --- KONTEN DISKUSI --- */}
        <div
          style={{
            marginTop: '20px',
            padding: '20px',
            border: '1px solid #ccc',
            borderRadius: '8px',
          }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              marginBottom: '15px',
            }}
          >
            <img
              src={threadDetail.owner.avatar}
              alt={threadDetail.owner.name}
              width="40"
              style={{ borderRadius: '50%' }}
            />
            <div>
              <strong>{threadDetail.owner.name}</strong>
              <div style={{ fontSize: '12px', color: '#777' }}>
                {new Date(threadDetail.createdAt).toLocaleDateString('id-ID')}
              </div>
            </div>
          </div>
          <h2 style={{ margin: '0 0 15px 0' }}>{threadDetail.title}</h2>
          <div
            dangerouslySetInnerHTML={{ __html: threadDetail.body }}
            style={{ lineHeight: '1.6' }}
          />
        </div>

        <div style={{ marginTop: '30px', marginBottom: '30px' }}>
          <h3 className="font-bold">Beri Komentar</h3>
          <form onSubmit={onCommentSubmit}>
            <textarea
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Tulis pendapatmu..."
              style={{
                border: '1px solid #ccc',
                width: '100%',
                padding: '10px',
                minHeight: '100px',
                marginBottom: '10px',
              }}
              required
            />
            <button
              type="submit"
              style={{
                padding: '10px 20px',
                backgroundColor: '#0056b3',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
              }}
            >
              Kirim Komentar
            </button>
          </form>
        </div>

        {/* --- DAFTAR KOMENTAR & TOMBOL VOTE --- */}
        <h3 style={{ marginTop: '30px' }}>
          Komentar ({threadDetail.comments.length})
        </h3>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
          {threadDetail.comments.map((comment) => (
            <div
              key={comment.id}
              style={{
                padding: '15px',
                backgroundColor: '#f9f9f9',
                borderRadius: '8px',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  marginBottom: '10px',
                }}
              >
                <img
                  src={comment.owner.avatar}
                  alt={comment.owner.name}
                  width="30"
                  style={{ borderRadius: '50%' }}
                />
                <strong>{comment.owner.name}</strong>
              </div>

              <div dangerouslySetInnerHTML={{ __html: comment.content }} />

              {/* TOMBOL JEMPOL KOMENTAR ADA DI SINI */}
              <div
                style={{
                  display: 'flex',
                  gap: '10px',
                  marginTop: '10px',
                  alignItems: 'center',
                }}
              >
                <button
                  onClick={() => dispatch(asyncToggleUpvoteComment(comment.id))}
                  style={{
                    display: 'flex',
                    gap: '5px',
                    alignItems: 'center',
                    cursor: 'pointer',
                    background: 'none',
                    border: 'none',
                    color: comment.upVotesBy.includes(authUser?.id)
                      ? 'red'
                      : '#777', // Hijau jika di-upvote
                    fontWeight: comment.upVotesBy.includes(authUser?.id)
                      ? 'bold'
                      : 'normal',
                  }}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="size-6"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12Z"
                    />
                  </svg>
                </button>

                {comment.upVotesBy.length && (
                  <small className="font-bold">
                    {comment.upVotesBy.length} Suka
                  </small>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export default DetailPage;
