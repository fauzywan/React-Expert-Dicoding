import React from 'react';
// import { useSelector, useDispatch } from 'react-redux';
// import { asyncPopulateLeaderboards } from '../states/leaderboards/leaderboardsSlice';

// --- 1. SIAPKAN DATA DUMMY ---
const dummyLeaderboards = [
  {
    user: {
      id: 'u-1',
      name: 'Iwan Fauzy',
      avatar: 'https://ui-avatars.com/api/?name=Iwan+Fauzy&background=random',
    },
    score: 2500,
  },
  {
    user: {
      id: 'u-2',
      name: 'Dimas Saputra',
      avatar:
        'https://ui-avatars.com/api/?name=Dimas+Saputra&background=random',
    },
    score: 1850,
  },
  {
    user: {
      id: 'u-3',
      name: 'Siti Aminah',
      avatar: 'https://ui-avatars.com/api/?name=Siti+Aminah&background=random',
    },
    score: 1200,
  },
  {
    user: {
      id: 'u-4',
      name: 'Budi Santoso',
      avatar: 'https://ui-avatars.com/api/?name=Budi+Santoso&background=random',
    },
    score: 950,
  },
  {
    user: {
      id: 'u-5',
      name: 'Ayu Lestari',
      avatar: 'https://ui-avatars.com/api/?name=Ayu+Lestari&background=random',
    },
    score: 420,
  },
];

function LeaderboardPage() {
  // --- 2. MATIKAN SEMENTARA REDUX ---
  // const leaderboards = useSelector((state) => state.leaderboards);
  // const dispatch = useDispatch();

  // useEffect(() => {
  //   dispatch(asyncPopulateLeaderboards());
  // }, [dispatch]);

  // --- 3. GUNAKAN DATA DUMMY ---
  const leaderboards = dummyLeaderboards;

  return (
    <section style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <header style={{ marginBottom: '30px', textAlign: 'center' }}>
        <h2 style={{ fontSize: '28px', color: '#333' }}>
          🏆 Klasemen Pengguna
        </h2>
        <p style={{ color: '#666' }}>
          Daftar kontributor dengan skor tertinggi di Forum
        </p>
      </header>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {leaderboards.map((item, index) => {
          const isTopThree = index < 3;
          return (
            <div
              key={item.user.id}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '15px 20px',
                backgroundColor: isTopThree ? '#fff' : '#f8f9fa',
                border: isTopThree ? '2px solid #ffd700' : '1px solid #eee',
                borderRadius: '12px',
                boxShadow: isTopThree
                  ? '0 4px 12px rgba(255, 215, 0, 0.2)'
                  : 'none',
              }}
            >
              <div
                style={{ display: 'flex', alignItems: 'center', gap: '15px' }}
              >
                <span
                  style={{
                    fontSize: '20px',
                    fontWeight: '900',
                    color:
                      index === 0
                        ? '#ffd700'
                        : index === 1
                          ? '#c0c0c0'
                          : index === 2
                            ? '#cd7f32'
                            : '#bbb',
                    width: '30px',
                  }}
                >
                  #{index + 1}
                </span>
                <img
                  src={item.user.avatar}
                  alt={item.user.name}
                  width="45"
                  height="45"
                  style={{ borderRadius: '50%', border: '2px solid #fff' }}
                />
                <div style={{ display: 'flex', flexDirection: 'column' }}>
                  <strong style={{ fontSize: '16px' }}>{item.user.name}</strong>
                  <span style={{ fontSize: '12px', color: '#888' }}>
                    Aktif Berdiskusi
                  </span>
                </div>
              </div>

              <div style={{ textAlign: 'right' }}>
                <span
                  style={{
                    fontSize: '22px',
                    fontWeight: 'bold',
                    color: '#0056b3',
                  }}
                >
                  {item.score}
                </span>
                <div
                  style={{
                    fontSize: '10px',
                    color: '#999',
                    textTransform: 'uppercase',
                  }}
                >
                  Poin
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

export default LeaderboardPage;
