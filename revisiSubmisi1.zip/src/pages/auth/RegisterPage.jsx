import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
// Sesuaikan import thunk register ini dengan nama aslimu
import { asyncRegisterUser } from '../../states/users/usersSlice';

function RegisterPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const onRegister = (e) => {
    e.preventDefault();
    dispatch(asyncRegisterUser({ name, email, password })).then(() => {
      // Otomatis pindah ke halaman login jika register sukses
      navigate('/');
    });
  };

  return (
    <section className="flex justify-center items-center min-h-[80vh] px-4 mt-5">
      <div
        className="w-full max-w-md bg-white"
        style={{
          border: '1px solid #ccc',
          padding: '30px',
          borderRadius: '8px',
        }}
      >
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold" style={{ color: '#0056b3' }}>
            Buat Akun Baru
          </h2>
          <p style={{ color: '#777', fontSize: '14px', marginTop: '5px' }}>
            Bergabunglah dengan komunitas Dkuz
          </p>
        </div>

        <form onSubmit={onRegister} className="flex flex-col gap-4">
          <div>
            <label className="block mb-1 font-bold text-sm text-gray-700">
              Nama Lengkap
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Iwan Fauzy"
              required
              className="w-full outline-none focus:ring-2 focus:ring-[#0056b3]"
              style={{
                padding: '12px',
                border: '1px solid #ccc',
                borderRadius: '4px',
              }}
            />
          </div>

          <div>
            <label className="block mb-1 font-bold text-sm text-gray-700">
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="nama@email.com"
              required
              className="w-full outline-none focus:ring-2 focus:ring-[#0056b3]"
              style={{
                padding: '12px',
                border: '1px solid #ccc',
                borderRadius: '4px',
              }}
            />
          </div>

          <div>
            <label className="block mb-1 font-bold text-sm text-gray-700">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimal 6 karakter"
              required
              className="w-full outline-none focus:ring-2 focus:ring-[#0056b3]"
              style={{
                padding: '12px',
                border: '1px solid #ccc',
                borderRadius: '4px',
              }}
            />
          </div>

          <button
            type="submit"
            className="w-full font-bold cursor-pointer transition-opacity hover:opacity-90 mt-2"
            style={{
              padding: '12px',
              backgroundColor: '#0056b3',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
            }}
          >
            Daftar Sekarang
          </button>
        </form>

        <p className="text-center mt-6 text-sm" style={{ color: '#555' }}>
          Sudah punya akun?{' '}
          <Link
            to="/"
            className="font-bold hover:underline"
            style={{ color: '#0056b3' }}
          >
            Masuk di sini
          </Link>
        </p>
      </div>
    </section>
  );
}

export default RegisterPage;
